<link rel="stylesheet" href="jquery.datetimepicker.min.css">
<script src="jquery.js"></script>
<script src="jquery.datetimepicker.full.js"></script>


<input id="datetime">



<script>
    $("#datetime").datetimepicker();
	</script>