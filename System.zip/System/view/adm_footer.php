        <!-- Begin footer content -->
        <footer class="footer fixed-bottom py-3">
            <div class="container text-center">
                <span class="text-muted">&copy;TMI-Grupo2 2020</span>
            </div>
        </footer>